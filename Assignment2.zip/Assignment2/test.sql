USE SWE4633FirstDB;
SELECT * From grades;
